package aiss.client.maps;

import com.google.gwt.dom.client.Document;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.maps.gwt.client.GoogleMap;
import com.google.maps.gwt.client.InfoWindow;
import com.google.maps.gwt.client.InfoWindowOptions;
import com.google.maps.gwt.client.LatLng;
import com.google.maps.gwt.client.MapOptions;
import com.google.maps.gwt.client.MapTypeId;
import com.google.maps.gwt.client.Marker;
import com.google.maps.gwt.client.MarkerOptions;
import com.google.maps.gwt.client.MouseEvent;
import com.google.maps.gwt.client.Marker.ClickHandler;

public class SchoolMap {
	
	static LatLng location;
	static GoogleMap map;
	
	public static void showMap() {
		location = LatLng.create(37.35818, -5.98637);
	    MapOptions mapOpts = MapOptions.create();
	    mapOpts.setZoom(16);
	    mapOpts.setCenter(location);
	    mapOpts.setMapTypeId(MapTypeId.ROADMAP);
	    map = GoogleMap.create(Document.get().getElementById("map_canvas"),mapOpts);

	    showSchool();
	}

	private static void showSchool() {
		
		InfoWindowOptions infowindowOpts = InfoWindowOptions.create();
	    infowindowOpts.setContent("<b>ETSII</b><br/>" +
        		"<img src='http://www.informatica.us.es/templates/ja_purity/images/Informa-150.jpg'/><br/>" +
        		"<a href='www.eii.us.es'>www.eii.us.es</a>");
	    final InfoWindow infowindow = InfoWindow.create(infowindowOpts);

	    MarkerOptions markerOpts = MarkerOptions.create();
	    markerOpts.setPosition(location);
	    markerOpts.setMap(map);
	    markerOpts.setTitle("ETSII");
	    final Marker marker = Marker.create(markerOpts);
	    marker.addClickListener(new ClickHandler() {
	      public void handle(MouseEvent event) {
	        infowindow.open(map, marker);
	      }
	    });	
	}
}
