package aiss.client.maps;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.dom.client.Document;
import com.google.maps.gwt.client.GoogleMap;
import com.google.maps.gwt.client.KmlLayer;
import com.google.maps.gwt.client.LatLng;
import com.google.maps.gwt.client.MapOptions;
import com.google.maps.gwt.client.MapTypeId;

public class KmlMap {
	
	static String KML_DEMO_URI = "http://www.juntadeandalucia.es/medioambiente/portal_web/web/temas_ambientales/geodiversidad/static_files/kml_inventario/sevilla.kml";
	
	public static void showMap() {
	    LatLng myLatLng = LatLng.create(37.35819, -5.98637);
	    MapOptions myOptions = MapOptions.create();
	    myOptions.setZoom(8.0);
	    myOptions.setCenter(myLatLng);
	    myOptions.setMapTypeId(MapTypeId.ROADMAP);
	    final GoogleMap map = GoogleMap.create(Document.get().getElementById("map_canvas"),myOptions);

	    KmlLayer ctaLayer = KmlLayer.create(KML_DEMO_URI);
	    ctaLayer.setMap(map);
	}
}
