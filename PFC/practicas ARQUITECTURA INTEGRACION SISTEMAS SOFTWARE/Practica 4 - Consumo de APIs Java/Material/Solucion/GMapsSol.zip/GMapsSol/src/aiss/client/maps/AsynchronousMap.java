package aiss.client.maps;

import com.google.gwt.jsonp.client.JsonpRequestBuilder;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Composite;

public class AsynchronousMap extends Composite {
	
	public static void showMap() {
		new JsonpRequestBuilder().send("http://maps.googleapis.com/maps/api/js?sensor=false",
	    	      new AsyncCallback<Void>(){
	    	        public void onFailure(Throwable e) {
	    	          Window.alert("Error loading map: " + e.getMessage());
	    	        }

	    	        public void onSuccess(Void result) {
	    	          SimpleMap.showMap();
	    	        }
	    	    });
	    
	    Window.alert("Execution continues while loading the map...");
	}
}
