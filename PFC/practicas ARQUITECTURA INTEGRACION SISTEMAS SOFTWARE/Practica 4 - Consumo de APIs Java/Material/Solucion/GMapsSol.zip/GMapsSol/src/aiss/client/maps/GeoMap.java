package aiss.client.maps;

import com.google.gwt.core.client.Callback;
import com.google.gwt.dom.client.Document;
import com.google.gwt.geolocation.client.Geolocation;
import com.google.gwt.geolocation.client.Position;
import com.google.gwt.geolocation.client.PositionError;
import com.google.gwt.geolocation.client.Position.Coordinates;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.maps.gwt.client.GoogleMap;
import com.google.maps.gwt.client.LatLng;
import com.google.maps.gwt.client.MapOptions;
import com.google.maps.gwt.client.MapTypeId;
import com.google.maps.gwt.client.Marker;
import com.google.maps.gwt.client.MarkerOptions;

public class GeoMap {
	
	static GoogleMap map;
	
	public static void showMap() {
		MapOptions myOptions = MapOptions.create();
	    myOptions.setZoom(14.0);
	    myOptions.setMapTypeId(MapTypeId.ROADMAP);
	    map= GoogleMap.create(Document.get().getElementById("map_canvas"), myOptions);
	    showUserPosition();
	}
	
	 // W3C Geolocation
	private static void showUserPosition() {
	    if (Geolocation.isSupported()) {
	      Geolocation.getIfSupported().getCurrentPosition(
	          new Callback<Position, PositionError>() {

	            @Override
	            public void onSuccess(Position result) {
	              Coordinates coords = result.getCoordinates();
	              LatLng location = LatLng.create(coords.getLatitude(),coords.getLongitude());
	              map.setCenter(location);
	              MarkerOptions markerOpts = MarkerOptions.create();
	      	      markerOpts.setPosition(location);
	      	      markerOpts.setMap(map);
	      	      markerOpts.setTitle("My position");
	      	      Marker.create(markerOpts);
	            }

	            @Override
	            public void onFailure(PositionError reason) {
	            	 Window.alert("Error getting position: " + reason.getMessage());
	            }
	          });
	    } else {
	      Window.alert("No Geolocation Support");
	    }
		
	}
}
