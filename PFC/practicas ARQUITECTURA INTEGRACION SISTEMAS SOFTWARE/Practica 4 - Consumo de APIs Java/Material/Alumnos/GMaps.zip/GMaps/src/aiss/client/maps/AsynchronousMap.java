package aiss.client.maps;

import com.google.gwt.jsonp.client.JsonpRequestBuilder;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Composite;

public class AsynchronousMap extends Composite {
	
	public static void showMap() {
		/** TODO: Cargar mapa de forma as�ncrona */
	    
	    Window.alert("Execution continues while loading the map...");
	}
}
