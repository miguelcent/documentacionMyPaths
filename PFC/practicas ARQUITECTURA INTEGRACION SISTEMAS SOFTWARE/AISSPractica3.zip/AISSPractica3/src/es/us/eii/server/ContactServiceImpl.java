package es.us.eii.server;

import java.util.ArrayList;
import java.util.List;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import es.us.eii.client.ContactService;
import es.us.eii.shared.Contact;

public class ContactServiceImpl extends RemoteServiceServlet implements
		ContactService {

	public List<Contact> contactsSimple;
	
	public void init(){
		contactsSimple = new ArrayList<Contact>();
		contactsSimple.add(new Contact("Antonio Manuel Gutierrez", "111111111"));
		contactsSimple.add(new Contact("Sergio Segura Rueda", "88888888"));
		contactsSimple.add(new Contact("Lionel Messi", "XXXXXXXX"));
		
	}
	@Override
	public List<Contact> getContacts() {
		// TODO Auto-generated method stub
		return contactsSimple;
	}

}
