package es.us.eii.client;

import java.util.HashMap;
import java.util.Map;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;

import com.google.gwt.user.client.ui.TextBox;

import es.us.eii.shared.Contact;

public class ViewEdit extends Composite{
 
	
	final TextBox name = new TextBox();
	final TextBox telephone = new TextBox();
	
	public ViewEdit(Map<String, String> params) {
		//MAIN PANEL
		 
		HorizontalPanel mainPanel = new HorizontalPanel();
		initWidget(mainPanel);
		
		final FlexTable formPanel = new FlexTable();
		
		Button saveButton = new Button("Save");
		
		if (params.containsKey("contact")){
			//CONSULTAR EL CONTACTO INDICADO COMO PARAMETRO
			
			
			
			saveButton.addClickHandler(new ClickHandler() {
			      public void onClick(ClickEvent event) {
			    	  Contact contact = new Contact(name.getValue(),telephone.getValue());
			    	  //GUARDAR EL CONTACTO EN SU INDICE
			      }
			    });
			
						
		}else{
			saveButton.addClickHandler(new ClickHandler() {
			      public void onClick(ClickEvent event) {
			    	  Contact contact = new Contact(name.getValue(),telephone.getValue());
			    	  //A�ADIR EL NUEVO CONTACTO
			    	  
			      }
			    });


			
		
		}
		//Contact contact = AISSPractica3Completa.contactsSimple.get(Integer.parseInt(id));
		
		formPanel.setStylePrimaryName("updateTable");
		formPanel.setWidget(0,0, new Label("Name"));
		formPanel.setWidget(0,1, name);
		formPanel.setWidget(1,0, new Label("Telephone"));
		formPanel.setWidget(1,1, telephone);
		mainPanel.add(formPanel);
		mainPanel.add(saveButton);
		
						
	}
	
	public void onGet(Contact c){
		name.setValue(c.getName());
		telephone.setValue(c.getTelephone());
	}
	
	public void onSave(){
		AISSPractica3.go("list");
	}
	
	

}
