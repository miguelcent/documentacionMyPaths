package es.us.eii.client;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;

import es.us.eii.shared.Contact;

public class ViewList extends Composite {
	
	
	private final ContactServiceAsync contactService = GWT
			.create(ContactService.class);
	
	private final FlexTable agendaPanel;
	private final HorizontalPanel mainPanel;
	
	public ViewList() {
		// MAIN PANEL
		mainPanel = new HorizontalPanel();
		initWidget(mainPanel);
		agendaPanel 	= new FlexTable();
		
		//PANEL PARA LA AGENDA
		agendaPanel.setStylePrimaryName("contactTable");
		agendaPanel.getRowFormatter().setStylePrimaryName(0,"firstRow");
		agendaPanel.setWidget(0,0, new Label("Name"));
		agendaPanel.setWidget(0,1, new Label("Telephone"));	
		agendaPanel.setWidget(0,2, new Label("Delete"));
		agendaPanel.setWidget(0,3, new Label("Update"));
		//CONSULTO TODOS LOS CONTACTOS
		contactService.getContacts(new AsyncCallback<List<Contact>>(){
			public void onSuccess(List<Contact> a){
				//RELLENO LA TABLA CON LOS RESULTADOS
				getContacts(a);
			}

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub
				
			}
			
			
		});			
			
		Button addButton = new Button("New");
		addButton.addClickHandler(new ClickHandler() {
		      public void onClick(ClickEvent event) {    	  
			    	//ABRIMOS LA VISTA DE CREACION DE CONTACTO
		    	  AISSPractica3.go("create");
		      }
		    });
		mainPanel.add(agendaPanel);
		mainPanel.add(addButton);		
	}
	
	
	/** METODO QUE INSERTA LOS DATOS OBTENIDOS DE SERVIDOR Y LOS INSERTA EN PANEL FLEXTABLE */
	public final void getContacts(List<Contact> 	contactsSimple){
	 
		int i = 0;
		final List<Contact> contacts = contactsSimple;
		for (Contact key: contactsSimple){
			final Contact keySearch = key;
			agendaPanel.setWidget(i+1, 0, new Label(key.getName()));
			agendaPanel.setWidget(i+1, 1, new Label(key.getTelephone()));
			
 
			Button deleteButton = new Button("Delete");
			deleteButton.addClickHandler(new ClickHandler() {
			      public void onClick(ClickEvent event) {
			        int indexRemoved = contacts.indexOf(keySearch);
			        //BORRAR EL CONTACTO ELEGIDO
			      }
			    });		
			agendaPanel.setWidget(i+1, 2, deleteButton);
			
			
			Button updateButton = new Button("Update");
			updateButton.addClickHandler(new ClickHandler() {
			      public void onClick(ClickEvent event) {
			    	//ABRIMOS LA VISTA DE EDICION DEL CONTACTO
			        int indexUpdated = contacts.indexOf(keySearch);
			        Map<String,String> map = new HashMap<String,String>();
			        map.put("contact", indexUpdated+"");
			        AISSPractica3.go("update",map);
			      }
			    });		
			agendaPanel.setWidget(i+1, 3, updateButton);	
			i++;		    
		}

		

		
	}
}
