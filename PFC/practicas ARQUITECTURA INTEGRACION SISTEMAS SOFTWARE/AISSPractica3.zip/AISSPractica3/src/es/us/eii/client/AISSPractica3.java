package es.us.eii.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import es.us.eii.shared.Contact;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.RootPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class AISSPractica3 implements EntryPoint {
	
	public void onModuleLoad() {
		
		go("init", new HashMap<String,String>());
	}
	
	public static void go(String token){
		AISSPractica3.go(token, new HashMap<String,String>());
	}
	
	// FLOW MANAGEMENT
	public static void go(String token, Map<String,String> params){
		Panel p = RootPanel.get();
		if (token=="list" || token=="init" ){
			p.clear();
			p.add(new ViewList());
		}else if (token=="create" ){
			//NEW WINDOW: p.clear();
			p.add(new ViewEdit(params));
		}else if (token=="update"){
			//NEW WINDOW: p.clear();
			p.add(new ViewEdit(params));
		}
		
	}
	
}
