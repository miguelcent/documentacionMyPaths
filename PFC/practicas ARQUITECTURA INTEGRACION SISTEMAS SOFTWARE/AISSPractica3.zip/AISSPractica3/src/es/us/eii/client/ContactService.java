package es.us.eii.client;
import java.util.List;

import es.us.eii.shared.Contact;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("contact")
public interface ContactService extends RemoteService {

	List<Contact> getContacts();
}
