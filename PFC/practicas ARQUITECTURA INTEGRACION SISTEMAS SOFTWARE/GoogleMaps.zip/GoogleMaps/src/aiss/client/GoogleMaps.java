package aiss.client;

import aiss.client.maps.CustomizedMap;
import aiss.client.maps.IMap;
import aiss.client.maps.KmlOverlayMap;
import aiss.client.maps.SchoolMap;
import aiss.client.maps.SearchMap;
import aiss.client.maps.SimpleMap;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.maps.client.Maps;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class GoogleMaps implements EntryPoint {
	HorizontalPanel mapSelectorPanel = new HorizontalPanel();
	Label statusLabel = new Label();

  // GWT module entry point method.
  public void onModuleLoad() {
	  
	  final ListBox widget = new ListBox();
	  widget.addItem("Ex1 - Simple Map","basicMap");
	  widget.addItem("Ex2 - Customized Map","customizedMap");
	  widget.addItem("Ex3 - School Map", "schoolMap");
	  widget.addItem("Ex4 - KML Overlay Map", "kmlOverlayMap");
	  widget.addItem("Ex5 - Search Map", "searchMap");
	  
	  widget.addChangeHandler(new ChangeHandler() {
		
		@Override
		public void onChange(ChangeEvent event) {
			statusLabel.setText("Loading Map...");
			RootPanel.get("map").clear();
			showMap(widget.getValue(widget.getSelectedIndex()));

		}
	});

	  mapSelectorPanel.add(widget);
	  
	   // Add the widget to the HTML host page
	   RootPanel.get("mapselector").add(mapSelectorPanel); 
	   RootPanel.get("mapselector").add(statusLabel); 
	   
	   // Show basic map
	   showMap("basicMap");
	  

  }

  
  private void showMap(final String mapType) {
	  

	  /*
	    * Asynchronously loads the Maps API.
	    *
	    * The first parameter should be a valid Maps API Key to deploy this
	    * application on a public server, but a blank key will work for an
	    * application served from localhost.
	   */
	   Maps.loadMapsApi("", "2", false, new Runnable() {
	      public void run() {
	        
	    	  // Create Map Class 
	    	  IMap mapClass = null;
	    	  if (mapType.equalsIgnoreCase("basicMap"))
	    	  	mapClass = new SimpleMap(); 
	    	  else if (mapType.equalsIgnoreCase("customizedMap"))
		    	mapClass = new CustomizedMap();
	    	  else if (mapType.equalsIgnoreCase("schoolMap"))
		    	  	mapClass = new SchoolMap();
	    	  else if (mapType.equalsIgnoreCase("kmlOverlayMap"))
		    	  	mapClass = new KmlOverlayMap();
	    	  else if (mapType.equalsIgnoreCase("searchMap"))
		    	  	mapClass = new SearchMap();
	    	  
	    	  if (mapClass==null)
	    		  statusLabel.setText("Map not created");
	    	  else {
				  // Create main panel. Add controls and map
				  final VerticalPanel panel = new VerticalPanel();
				  panel.setWidth("100%");
				  if (mapClass.getControls()!=null)
					  panel.add(mapClass.getControls());
				  
				  panel.add(mapClass.getMap());
				     
				   // Add the map to the HTML host page
				   RootPanel.get("map").add(panel);
				   
				   statusLabel.setText("Map loaded");
	    	  }
	      }
	    });
  }
}
