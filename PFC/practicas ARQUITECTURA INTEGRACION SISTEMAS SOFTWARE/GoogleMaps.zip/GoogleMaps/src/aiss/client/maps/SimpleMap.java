package aiss.client.maps;

import com.google.gwt.maps.client.MapWidget;
import com.google.gwt.maps.client.event.MapZoomEndHandler;
import com.google.gwt.maps.client.event.MapZoomEndHandler.MapZoomEndEvent;
import com.google.gwt.maps.client.geom.LatLng;
import com.google.gwt.user.client.ui.Widget;

public class SimpleMap implements IMap  {

	
	/*
	 * - Create a simple map centered in Seville (latitude = 37.3826400, longitude: -5.9962951)
	 * - Width=100%, Height=500px
	 */
	public MapWidget getMap() {

	   
	    return null;
	}

	public Widget getControls() {
		return null;
	}	
}

