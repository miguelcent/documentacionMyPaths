package aiss.client.maps;

/**
 * Create a map of 500x500px centered in Seville (Latitude = 37.391410, Longitude: -5.959177). 
 * Controls to switch map types and zooming are shown. Zoom can be set by using double click or 
 * the scroll wheel.
 * 
 */


import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.NumberFormat;
import com.google.gwt.maps.client.InfoWindow;
import com.google.gwt.maps.client.InfoWindowContent;
import com.google.gwt.maps.client.MapWidget;
import com.google.gwt.maps.client.control.LargeMapControl;
import com.google.gwt.maps.client.control.MapTypeControl;
import com.google.gwt.maps.client.geocode.Geocoder;
import com.google.gwt.maps.client.geocode.LatLngCallback;
import com.google.gwt.maps.client.geom.LatLng;
import com.google.gwt.maps.client.overlay.Marker;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;


public class SearchMap implements IMap  {

	private HorizontalPanel panel = new HorizontalPanel();
	private TextBox searchTextBox = new TextBox();
	private Button searchButton = new Button("Search!");
	MapWidget map = null;
	
	/*
	 * - Create a simple map centered in Seville (latitude = 37.3826400, longitude: -5.9962951)
	 * - Width=100%, Height=500px.
	 * - Integrated controls to switch map types and zooming are shown.
	 */
	public MapWidget getMap() {
		
	    return null;
	}

	/*
	 * - Return a panel including a textbox and a button to perform the search.
	 * - Register a click handler for the button
	 */
	public Widget getControls() {
		
		return null;
	}
	
	
	/*
	 * - Obtain the latitude and longitude of the input address
	 * - Show the address in the map using a marker and an information window
	 */
	private void showAddress() {
		
	}
	
}

