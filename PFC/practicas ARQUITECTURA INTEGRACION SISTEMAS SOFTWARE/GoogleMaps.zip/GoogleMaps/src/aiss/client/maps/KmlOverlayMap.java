package aiss.client.maps;

/**
 * Create a map of 500x500px centered in Seville (Latitude = 37.391410, Longitude: -5.959177). 
 * Controls to switch map types and zooming are shown. Zoom can be set by using double click or 
 * the scroll wheel.
 * 
 * http://www.juntadeandalucia.es/medioambiente/site/web/menuitem.a5664a214f73c3df81d8899661525ea0/?vgnextoid=d733e6ed46a28110VgnVCM1000000624e50aRCRD&vgnextchannel=023efe1a2c9c6010VgnVCM1000000624e50aRCRD&lr=lang_es
 * 
 */

import com.google.gwt.core.client.GWT;
import com.google.gwt.maps.client.MapWidget;
import com.google.gwt.maps.client.control.LargeMapControl;
import com.google.gwt.maps.client.control.MapTypeControl;

import com.google.gwt.maps.client.geom.LatLng;
import com.google.gwt.maps.client.overlay.GeoXmlLoadCallback;
import com.google.gwt.maps.client.overlay.GeoXmlOverlay;

import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Widget;


public class KmlOverlayMap implements IMap {

	private  String KML_DEMO_URI = "http://www.juntadeandalucia.es/medioambiente/BIO/DOC/ARB_SING/kml/arb_sing_se.kml";

	/*
	 * - Create a simple map centered in Seville (latitude = 37.3826400, longitude: -5.9962951)
	 * - Width=100%, Height=500px.
	 * - Integrated controls to switch map types and zooming are shown.
	 * - Overlay geographical data included in a KML file
	 */
	public MapWidget getMap() {

		return null;
	}


	public Widget getControls() {
		return null;
	}

}
