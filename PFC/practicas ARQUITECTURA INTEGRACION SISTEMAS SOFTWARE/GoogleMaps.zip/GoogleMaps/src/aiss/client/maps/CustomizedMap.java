package aiss.client.maps;



import com.google.gwt.maps.client.MapWidget;
import com.google.gwt.maps.client.control.LargeMapControl;
import com.google.gwt.maps.client.control.MapTypeControl;
import com.google.gwt.maps.client.control.SmallMapControl;
import com.google.gwt.maps.client.geom.LatLng;
import com.google.gwt.user.client.ui.Widget;

public class CustomizedMap implements IMap  {

	/*
	 * - Create a simple map centered in Seville (latitude = 37.3826400, longitude: -5.9962951)
	 * - Width=100%, Height=500px.
	 * - Integrated controls to switch map types and zooming are shown. Zoom can be set by using double click or 
	 *   the scroll wheel.
	 */
	public MapWidget getMap() {

	    
	    return null;
	}


	public Widget getControls() {
		return null;
	}
	
}

