package aiss.client.maps;

import com.google.gwt.maps.client.MapWidget;
import com.google.gwt.user.client.ui.Widget;

public interface IMap {

	public MapWidget getMap();
	public Widget getControls();
}
