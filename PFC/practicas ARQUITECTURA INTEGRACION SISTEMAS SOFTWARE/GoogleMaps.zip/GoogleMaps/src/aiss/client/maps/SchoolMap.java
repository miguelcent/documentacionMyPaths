package aiss.client.maps;

/**
 * Create a map of 500x500px centered in Seville (Latitude = 37.391410, Longitude: -5.959177). 
 * Controls to switch map types and zooming are shown. Zoom can be set by using double click or 
 * the scroll wheel.
 * 
 */

import com.google.gwt.maps.client.InfoWindow;
import com.google.gwt.maps.client.InfoWindowContent;
import com.google.gwt.maps.client.MapWidget;
import com.google.gwt.maps.client.control.LargeMapControl;
import com.google.gwt.maps.client.control.MapTypeControl;
import com.google.gwt.maps.client.control.SmallMapControl;
import com.google.gwt.maps.client.geom.LatLng;
import com.google.gwt.maps.client.overlay.Marker;
import com.google.gwt.user.client.ui.Widget;

public class SchoolMap implements IMap  {

	/*
	 * - Create a simple map centered in Seville (latitude = 37.3826400, longitude: -5.9962951)
	 * - Width=100%, Height=500px.
	 * - Integrated controls to switch map types and zooming are shown.
	 * - Overlay a marker and an information window showing the address of ETSII.
	 */
	public MapWidget getMap() {
   
	    return null;
	}

	
	public Widget getControls() {
	
		return null;
	}
	
}

